"""
Finite Element Analysis UI Package
"""

from .main_ui import launch_ui

__all__ = ['launch_ui']
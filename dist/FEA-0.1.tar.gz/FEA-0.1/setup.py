from setuptools import setup, find_packages

setup(


    name='FEA',


    version='0.1',


    packages=find_packages(),


    install_requires=[


        # 这里列出你的包依赖


    ],


)